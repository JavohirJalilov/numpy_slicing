from setuptools import setup

setup(
   name='numpySlicingTest',
   version='0.0.1',
   packages=['numpySlicingTest'],
   description='This is Numpy Slicing Test',
) 