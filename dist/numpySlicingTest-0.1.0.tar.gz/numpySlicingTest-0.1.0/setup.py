from setuptools import setup

setup(
   name='numpySlicingTest',
   version='0.1.0',
   packages=['numpySlicingTest'],
   description='This is Numpy Slicing Test',
   # required library
    install_requires=['numpy', 'requests'],
)